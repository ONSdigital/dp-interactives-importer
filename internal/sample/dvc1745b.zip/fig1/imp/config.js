var dvc = {
        "essential": {
                "graphic_data_url": "data.csv",
                "screenreadertext": "", //will replace default screenreader text - use if fuller description needed
                "dateFormat": "%b-%y",
                "legendStyle": "line",
                "directLabeling": false,
                "directLabelingAdjust": [{ "x": 0, "y": 0 }, { "x": 0, "y": 7 }, { "x": 0, "y": -43 }],
                "colour_palette": ["#206095", "#A8BD27"],
                "colour_palette_labels": ["#206095", "#A8BD27"],
                "sourceText": [],
                "sourceURL": ["http://www.ons.gov.uk"],
                "draggable": false,
                "annotationsChart": [
                        {
                                "xVal": "2019-03-01T00:00:00.000Z",
                                "yVal": 29.5,
                                "path": "",
                                "text": "Brexit deadlines",
                                "textOffset": [15, -14]
                        },

                        {
                                "xVal": "2020-12-01T00:00:00.000Z",
                                "yVal": 37,
                                "path": "",
                                "text": "End of Brexit transition period",
                                "textOffset": [0, -14]
                        },

                        {
                                "xVal": "2020-03-01T00:00:00.000Z",
                                "yVal": 6,
                                "path": "",
                                "text": "Coronavirus (COVID-19)  pandemic",
                                "textOffset": [5, 0]
                        }
                ],

                "wordwrap": [30, 20, 15],
                "annoAlign": ["start", "end", "start"],
                "annotationBullet": [/*"An annotation","Another annotation"*/],

                "circles": false,
                // "annotationCXCY":[
                //     ["Jan-93","68.4"],
                //     ["Jan-08","73"]
                // ],
                //"annotationColour": ["green"],

                "yAxisLabel": "£ billion, seasonally adjusted",
                "yAxisScale": [0, 30], //Options: auto_min_max, auto_zero_max, or specify array eg [-20,100]
                "yAxisBreak": false,
                "yAxisBreak_sm_md_lg": [65, 65, 65]
        },

        "optional": {
                "margin_sm": [80, 30, 25, 25], //[top,right,bottom,left]
                "margin_md": [80, 30, 25, 25],
                "margin_lg": [80, 30, 25, 25],

                "aspectRatio_sm": [16, 10],
                "aspectRatio_md": [16, 10],
                "aspectRatio_lg": [16, 10],

                "mobileBreakpoint": 414,

                "xAxisTextFormat_sm_md_lg": ["%b %y", "%b %y", "%b %y"],

                "x_num_ticks_sm_md_lg": [6, 9, 2],
                "y_num_ticks_sm_md_lg": [5, 5, 5],

                "lineMarkers": false,

                "vertical_line": true,
                "annotateLineX1_Y1_X2_Y2": [
                        [["Mar-19", "29"], ["Mar-19", "0"]],
                        [["Oct-19", "29"], ["Oct-19", "0"]],
                        [["Dec-20", "36"], ["Dec-20", "0"]],
                        [["Mar-19", "29"], ["Oct-19", "29"]],
                        [["May-19", "29"], ["May-19", "31"]]

                ],

                "annotateRect": true,
                "annotateRectX_Y": [
                        [["Mar-20", 30], ["Nov-21", 0]]
                ],
                "lineColor_opcty": [["#888", 0.2]],

                "centre_line": false,
                "centre_line_value": 25
        }
}
